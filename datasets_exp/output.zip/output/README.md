for medqa output

* l2r_m: default
* l2r_m_refusal: tmp output for refusal analysis
* l2r_m_original: output with original prompts without rag
* l2r_m_pure: output with new prompts without rag, threshold = 0.65
* l2r_m_rag: output with original prompts with rag, threshold = 0.65